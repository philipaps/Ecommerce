from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Proprietario)
admin.site.register(Veiculo)
admin.site.register(Acessorio)